package org.cipfpcheste.dam2.chefai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChefAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChefAiApplication.class, args);
    }

}

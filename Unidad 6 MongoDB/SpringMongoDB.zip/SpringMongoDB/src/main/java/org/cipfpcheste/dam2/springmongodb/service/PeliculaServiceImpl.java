package org.cipfpcheste.dam2.springmongodb.service;

import org.cipfpcheste.dam2.springmongodb.model.Pelicula;
import org.cipfpcheste.dam2.springmongodb.repository.PeliculaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PeliculaServiceImpl implements PeliculaService {

    @Autowired
    private PeliculaRepository peliculaRepository;

    @Override
    public List<Pelicula> obtenerTodasLasPeliculas() {
        return peliculaRepository.findAll();
    }

    @Override
    public Optional<Pelicula> obtenerPeliculaPorId(String id) {
        return peliculaRepository.findById(id);
    }

    @Override
    public Pelicula crearPelicula(Pelicula pelicula) {
        return peliculaRepository.save(pelicula);
    }

    @Override
    public Pelicula actualizarPelicula(String id, Pelicula peliculaActualizada) {
        return peliculaRepository.findById(id)
            .map(pelicula -> {
                pelicula.setTitulo(peliculaActualizada.getTitulo());
                pelicula.setAnyo(peliculaActualizada.getAnyo());
                pelicula.setDirector(peliculaActualizada.getDirector());
                pelicula.setPais(peliculaActualizada.getPais());
                pelicula.setGenero(peliculaActualizada.getGenero());
                pelicula.setDuracionMinutos(peliculaActualizada.getDuracionMinutos());
                pelicula.setClasificacion(peliculaActualizada.getClasificacion());
                pelicula.setActoresPrincipales(peliculaActualizada.getActoresPrincipales());
                pelicula.setPuntuacionImdb(peliculaActualizada.getPuntuacionImdb());
                pelicula.setTaquillaGlobalMillones(peliculaActualizada.getTaquillaGlobalMillones());
                pelicula.setOscars(peliculaActualizada.getOscars());
                pelicula.setPremiosGoya(peliculaActualizada.getPremiosGoya());
                return peliculaRepository.save(pelicula);
            })
            .orElse(null);
    }

    @Override
    public boolean eliminarPelicula(String id) {
        if (peliculaRepository.existsById(id)) {
            peliculaRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public List<Pelicula> buscarPorTitulo(String titulo) {
        return peliculaRepository.findByTituloContainingIgnoreCase(titulo);
    }

    @Override
    public List<Pelicula> buscarPorDirector(String director) {
        return peliculaRepository.findByDirectorContainingIgnoreCase(director);
    }

    @Override
    public List<Pelicula> buscarPorPais(String pais) {
        return peliculaRepository.findByPais(pais);
    }

    @Override
    public List<Pelicula> buscarPorAnyo(Integer anyo) {
        return peliculaRepository.findByAnyo(anyo);
    }

    @Override
    public List<Pelicula> buscarPorGenero(String genero) {
        return peliculaRepository.findByGeneroContaining(genero);
    }

    @Override
    public List<Pelicula> buscarPorPuntuacionMinima(Double puntuacion) {
        return peliculaRepository.findByPuntuacionImdbGreaterThanEqual(puntuacion);
    }

    @Override
    public List<Pelicula> obtenerPeliculasConOscars() {
        return peliculaRepository.findPeliculasConOscars();
    }

    @Override
    public List<Pelicula> obtenerPeliculasConGoyas() {
        return peliculaRepository.findPeliculasConGoyas();
    }
}

package org.cipfpcheste.dam2.springmongodb.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.cipfpcheste.dam2.springmongodb.model.Pelicula;
import org.cipfpcheste.dam2.springmongodb.service.PeliculaServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/peliculas")
@Tag(name = "Películas", description = "API para la gestión de películas")
public class PeliculaController {

    @Autowired
    private PeliculaServiceImpl peliculaServiceImpl;

    @Operation(
        summary = "Obtener todas las películas",
        description = "Retorna una lista completa de todas las películas almacenadas en la base de datos"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de películas obtenida exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping
    public ResponseEntity<List<Pelicula>> obtenerTodasLasPeliculas() {
        return ResponseEntity.ok(peliculaServiceImpl.obtenerTodasLasPeliculas());
    }

    @Operation(
        summary = "Obtener película por ID",
        description = "Retorna una película específica basada en su identificador único"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Película encontrada",
                     content = @Content(schema = @Schema(implementation = Pelicula.class))),
        @ApiResponse(responseCode = "404", description = "Película no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Pelicula> obtenerPeliculaPorId(
            @Parameter(description = "ID de la película a buscar", required = true)
            @PathVariable String id) {
        return peliculaServiceImpl.obtenerPeliculaPorId(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
        summary = "Crear nueva película",
        description = "Crea y almacena una nueva película en la base de datos"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Película creada exitosamente",
                     content = @Content(schema = @Schema(implementation = Pelicula.class))),
        @ApiResponse(responseCode = "400", description = "Datos de película inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @PostMapping
    public ResponseEntity<Pelicula> crearPelicula(
            @Parameter(description = "Datos de la película a crear", required = true)
            @RequestBody Pelicula pelicula) {
        Pelicula nuevaPelicula = peliculaServiceImpl.crearPelicula(pelicula);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevaPelicula);
    }

    @Operation(
        summary = "Actualizar película",
        description = "Actualiza los datos de una película existente"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Película actualizada exitosamente",
                     content = @Content(schema = @Schema(implementation = Pelicula.class))),
        @ApiResponse(responseCode = "404", description = "Película no encontrada"),
        @ApiResponse(responseCode = "400", description = "Datos de película inválidos"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @PutMapping("/{id}")
    public ResponseEntity<Pelicula> actualizarPelicula(
            @Parameter(description = "ID de la película a actualizar", required = true)
            @PathVariable String id,
            @Parameter(description = "Nuevos datos de la película", required = true)
            @RequestBody Pelicula pelicula) {
        Pelicula peliculaActualizada = peliculaServiceImpl.actualizarPelicula(id, pelicula);
        if (peliculaActualizada != null) {
            return ResponseEntity.ok(peliculaActualizada);
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(
        summary = "Eliminar película",
        description = "Elimina una película de la base de datos"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Película eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Película no encontrada"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPelicula(
            @Parameter(description = "ID de la película a eliminar", required = true)
            @PathVariable String id) {
        if (peliculaServiceImpl.eliminarPelicula(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(
        summary = "Buscar películas por título",
        description = "Busca películas que contengan el texto especificado en el título (sin distinción de mayúsculas/minúsculas)"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Búsqueda completada exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/buscar/titulo")
    public ResponseEntity<List<Pelicula>> buscarPorTitulo(
            @Parameter(description = "Texto a buscar en el título", required = true)
            @RequestParam String titulo) {
        return ResponseEntity.ok(peliculaServiceImpl.buscarPorTitulo(titulo));
    }

    @Operation(
        summary = "Buscar películas por director",
        description = "Busca películas dirigidas por el director especificado"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Búsqueda completada exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/buscar/director")
    public ResponseEntity<List<Pelicula>> buscarPorDirector(
            @Parameter(description = "Nombre del director", required = true)
            @RequestParam String director) {
        return ResponseEntity.ok(peliculaServiceImpl.buscarPorDirector(director));
    }

    @Operation(
        summary = "Buscar películas por país",
        description = "Busca películas producidas en el país especificado"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Búsqueda completada exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/buscar/pais")
    public ResponseEntity<List<Pelicula>> buscarPorPais(
            @Parameter(description = "País de producción", required = true)
            @RequestParam String pais) {
        return ResponseEntity.ok(peliculaServiceImpl.buscarPorPais(pais));
    }

    @Operation(
        summary = "Buscar películas por año",
        description = "Busca películas estrenadas en el año especificado"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Búsqueda completada exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/buscar/anyo")
    public ResponseEntity<List<Pelicula>> buscarPorAnyo(
            @Parameter(description = "Año de estreno", required = true, example = "1972")
            @RequestParam Integer anyo) {
        return ResponseEntity.ok(peliculaServiceImpl.buscarPorAnyo(anyo));
    }

    @Operation(
        summary = "Buscar películas por género",
        description = "Busca películas que pertenezcan al género especificado"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Búsqueda completada exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/buscar/genero")
    public ResponseEntity<List<Pelicula>> buscarPorGenero(
            @Parameter(description = "Género de la película", required = true, example = "Drama")
            @RequestParam String genero) {
        return ResponseEntity.ok(peliculaServiceImpl.buscarPorGenero(genero));
    }

    @Operation(
        summary = "Buscar películas por puntuación mínima",
        description = "Busca películas con una puntuación IMDB mayor o igual a la especificada"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Búsqueda completada exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/buscar/puntuacion")
    public ResponseEntity<List<Pelicula>> buscarPorPuntuacionMinima(
            @Parameter(description = "Puntuación mínima en IMDB", required = true, example = "8.0")
            @RequestParam Double puntuacion) {
        return ResponseEntity.ok(peliculaServiceImpl.buscarPorPuntuacionMinima(puntuacion));
    }

    @Operation(
        summary = "Obtener películas ganadoras de Oscars",
        description = "Retorna todas las películas que han ganado premios Oscar"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista obtenida exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/premios/oscars")
    public ResponseEntity<List<Pelicula>> obtenerPeliculasConOscars() {
        return ResponseEntity.ok(peliculaServiceImpl.obtenerPeliculasConOscars());
    }

    @Operation(
        summary = "Obtener películas ganadoras de Goyas",
        description = "Retorna todas las películas que han ganado premios Goya"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista obtenida exitosamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @GetMapping("/premios/goyas")
    public ResponseEntity<List<Pelicula>> obtenerPeliculasConGoyas() {
        return ResponseEntity.ok(peliculaServiceImpl.obtenerPeliculasConGoyas());
    }
}

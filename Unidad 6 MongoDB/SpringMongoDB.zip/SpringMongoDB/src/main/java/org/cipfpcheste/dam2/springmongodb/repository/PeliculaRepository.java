package org.cipfpcheste.dam2.springmongodb.repository;

import org.cipfpcheste.dam2.springmongodb.model.Pelicula;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PeliculaRepository extends MongoRepository<Pelicula, String> {
    
    // Buscar por título
    List<Pelicula> findByTituloContainingIgnoreCase(String titulo);
    
    // Buscar por director
    List<Pelicula> findByDirectorContainingIgnoreCase(String director);
    
    // Buscar por país
    List<Pelicula> findByPais(String pais);
    
    // Buscar por año
    List<Pelicula> findByAnyo(Integer anyo);
    
    // Buscar por género
    List<Pelicula> findByGeneroContaining(String genero);
    
    // Buscar películas con puntuación mayor o igual
    List<Pelicula> findByPuntuacionImdbGreaterThanEqual(Double puntuacion);
    
    // Buscar películas ganadoras de Oscars
    @Query("{ 'oscars': { $exists: true, $ne: null } }")
    List<Pelicula> findPeliculasConOscars();
    
    // Buscar películas ganadoras de Goyas
    @Query("{ 'premios_goya': { $exists: true, $ne: null } }")
    List<Pelicula> findPeliculasConGoyas();
}

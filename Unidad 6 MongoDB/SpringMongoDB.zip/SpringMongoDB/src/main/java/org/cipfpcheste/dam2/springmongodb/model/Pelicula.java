package org.cipfpcheste.dam2.springmongodb.model;

import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Document(collection = "Peli")
@Schema(description = "Modelo que representa una película en el sistema")
public class Pelicula {

    @Id
    @Schema(description = "Identificador único de la película", 
            example = "507f1f77bcf86cd799439011", 
            accessMode = Schema.AccessMode.READ_ONLY)
    private String id;

    @Schema(description = "Título de la película", 
            example = "El Padrino", 
            required = true)
    private String titulo;

    @Schema(description = "Año de estreno", 
            example = "1972", 
            required = true)
    private Integer anyo;

    @Schema(description = "Nombre del director", 
            example = "Francis Ford Coppola", 
            required = true)
    private String director;

    @Schema(description = "País de producción", 
            example = "Estados Unidos", 
            required = true)
    private String pais;

    @Schema(description = "Lista de géneros de la película", 
            example = "[\"Drama\", \"Crimen\"]", 
            required = true)
    private List<String> genero;

    @Field("duracion_minutos")
    @Schema(description = "Duración de la película en minutos", 
            example = "175")
    private Integer duracionMinutos;

    @Schema(description = "Clasificación por edad", 
            example = "R")
    private String clasificacion;

    @Field("actores_principales")
    @Schema(description = "Lista de actores principales", 
            example = "[\"Marlon Brando\", \"Al Pacino\", \"James Caan\"]")
    private List<String> actoresPrincipales;

    @Field("puntuacion_imdb")
    @Schema(description = "Puntuación en IMDB", 
            example = "9.2", 
            minimum = "0", 
            maximum = "10")
    private Double puntuacionImdb;

    @Field("taquilla_global_millones")
    @Schema(description = "Recaudación global en millones de dólares", 
            example = "246.1")
    private Double taquillaGlobalMillones;

    @Schema(description = "Número de premios Oscar ganados", 
            example = "3")
    private Integer oscars;

    @Field("premios_goya")
    @Schema(description = "Número de premios Goya ganados", 
            example = "0")
    private Integer premiosGoya;

    // Constructores
    public Pelicula() {
    }

    public Pelicula(String titulo, Integer anyo, String director, String pais,
                    List<String> genero, Integer duracionMinutos, String clasificacion,
                    List<String> actoresPrincipales, Double puntuacionImdb,
                    Double taquillaGlobalMillones) {
        this.titulo = titulo;
        this.anyo = anyo;
        this.director = director;
        this.pais = pais;
        this.genero = genero;
        this.duracionMinutos = duracionMinutos;
        this.clasificacion = clasificacion;
        this.actoresPrincipales = actoresPrincipales;
        this.puntuacionImdb = puntuacionImdb;
        this.taquillaGlobalMillones = taquillaGlobalMillones;
    }

    // Getters y Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Integer getAnyo() {
        return anyo;
    }

    public void setAnyo(Integer anyo) {
        this.anyo = anyo;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public List<String> getGenero() {
        return genero;
    }

    public void setGenero(List<String> genero) {
        this.genero = genero;
    }

    public Integer getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(Integer duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    public List<String> getActoresPrincipales() {
        return actoresPrincipales;
    }

    public void setActoresPrincipales(List<String> actoresPrincipales) {
        this.actoresPrincipales = actoresPrincipales;
    }

    public Double getPuntuacionImdb() {
        return puntuacionImdb;
    }

    public void setPuntuacionImdb(Double puntuacionImdb) {
        this.puntuacionImdb = puntuacionImdb;
    }

    public Double getTaquillaGlobalMillones() {
        return taquillaGlobalMillones;
    }

    public void setTaquillaGlobalMillones(Double taquillaGlobalMillones) {
        this.taquillaGlobalMillones = taquillaGlobalMillones;
    }

    public Integer getOscars() {
        return oscars;
    }

    public void setOscars(Integer oscars) {
        this.oscars = oscars;
    }

    public Integer getPremiosGoya() {
        return premiosGoya;
    }

    public void setPremiosGoya(Integer premiosGoya) {
        this.premiosGoya = premiosGoya;
    }
}
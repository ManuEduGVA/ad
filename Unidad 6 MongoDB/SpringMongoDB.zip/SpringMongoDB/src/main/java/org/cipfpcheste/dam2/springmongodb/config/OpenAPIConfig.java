package org.cipfpcheste.dam2.springmongodb.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenAPIConfig {

    @Bean
    public OpenAPI peliculasAPI() {
        Server localServer = new Server();
        localServer.setUrl("http://localhost:8080");
        localServer.setDescription("Servidor de Desarrollo Local de 2º DAM");

        Contact contact = new Contact();
        contact.setEmail("manu@cipfpcheste.dam2");
        contact.setName("José Manuel Romero");
        contact.setUrl("https://portal.edu.gva.es/fpcheste/");

        License mitLicense = new License()
                .name("MIT License")
                .url("https://choosealicense.com/licenses/mit/");

        Info info = new Info()
                .title("API de Gestión de Películas")
                .version("1.0.0")
                .contact(contact)
                .description("API REST para la gestión de películas con MongoDB")
                .termsOfService("https://www.cipfpcheste.dam2/terms")
                .license(mitLicense);

        return new OpenAPI()
                .info(info)
                .servers(List.of(localServer));
    }
}
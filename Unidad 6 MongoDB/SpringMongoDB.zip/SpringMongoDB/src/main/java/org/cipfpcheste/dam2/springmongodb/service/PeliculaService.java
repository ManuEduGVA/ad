package org.cipfpcheste.dam2.springmongodb.service;

import org.cipfpcheste.dam2.springmongodb.model.Pelicula;

import java.util.List;
import java.util.Optional;

public interface PeliculaService {
    
    // Operaciones CRUD básicas
    List<Pelicula> obtenerTodasLasPeliculas();
    
    Optional<Pelicula> obtenerPeliculaPorId(String id);
    
    Pelicula crearPelicula(Pelicula pelicula);
    
    Pelicula actualizarPelicula(String id, Pelicula peliculaActualizada);
    
    boolean eliminarPelicula(String id);
    
    // Búsquedas específicas
    List<Pelicula> buscarPorTitulo(String titulo);
    
    List<Pelicula> buscarPorDirector(String director);
    
    List<Pelicula> buscarPorPais(String pais);
    
    List<Pelicula> buscarPorAnyo(Integer anyo);
    
    List<Pelicula> buscarPorGenero(String genero);
    
    List<Pelicula> buscarPorPuntuacionMinima(Double puntuacion);
    
    List<Pelicula> obtenerPeliculasConOscars();
    
    List<Pelicula> obtenerPeliculasConGoyas();
}

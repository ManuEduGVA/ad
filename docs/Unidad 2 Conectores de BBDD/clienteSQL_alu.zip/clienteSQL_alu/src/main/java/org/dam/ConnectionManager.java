package org.dam;

import java.io.*;
import java.sql.*;

public class ConnectionManager {
    private String server;
    private String port;
    private String user;
    private String pass;
    private Connection connection;

    public ConnectionManager() {
        this.server = "";
        this.port = "";
        this.user = "";
        this.pass = "";
        this.connection = null;
    }

    public ConnectionManager(String server, String port, String user, String pass) {

    }

    public Connection connectDBMS() {
        try {

        } catch (SQLException e) {
            System.out.println(Colores.Red + "Error conectando al servidor: " + e.getMessage() + Colores.Reset);
            return null;
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void showInfo() {

    }

    public void showDatabases() {
        try {

            }
        } catch (SQLException e) {
            System.out.println(Colores.Red + "Error mostrando bases de datos: " + e.getMessage() + Colores.Reset);
        }
    }

    public void importScript(String scriptPath) {



    }
    public void startShell() {
        System.out.println(Colores.Green +
                "Cliente MySQL iniciado. Escribe 'help' para ver los comandos disponibles." + Colores.Reset);

        while (true) {
            String prompt = Colores.Green + "(" + user + ") on " + server + ":" + port + "> " + Colores.Reset;
            String input = Utilidades.leerLinea(prompt).trim();

            switch (input) {
                case "show databases":
                case "show db":
                case "show database":
                    showDatabases();
                    break;

                case "info":
                    showInfo();
                    break;

                case "quit":
                case "exit":
                    System.out.println(Colores.Yellow + "Saliendo..." + Colores.Reset);
                    try {
                        if (connection != null && !connection.isClosed()) {
                            connection.close();
                        }
                    } catch (SQLException e) {
                        // Ignorar errores al cerrar
                    }
                    return;

                default:
                    if (input.startsWith("import ")) {
                        String[] parts = input.split(" ", 2);
                        if (parts.length == 2) {
                            importScript(parts[1]);
                        } else {
                            System.out.println(Colores.Red + "Uso: import <ruta_del_script>" + Colores.Reset);
                        }
                    } else if (input.startsWith("use ")) {
                        String[] parts = input.split(" ", 2);
                        if (parts.length == 2) {
                            String databaseName = parts[1];
                            // Cambiar al modo base de datos
                            DatabaseManager dbManager = new DatabaseManager(server, port, user, pass, databaseName);
                            Connection dbConnection = dbManager.connectDatabase();
                            if (dbConnection != null) {
                                dbManager.startShell();
                            }
                        } else {
                            System.out.println(Colores.Red + "Uso: use <nombre_base_datos>" + Colores.Reset);
                        }
                    } else if (!input.isEmpty()) {
                        System.out.println(Colores.Red + "Comando no reconocido: " + input + Colores.Reset);
                    }
                    break;
            }
        }
    }

}

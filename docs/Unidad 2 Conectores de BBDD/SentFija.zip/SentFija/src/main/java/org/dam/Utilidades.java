package org.dam;

import java.util.Scanner;

public class Utilidades {

    public static String leerTextoC(String cadena) {
        Scanner sc = new Scanner(System.in);
        System.out.println(cadena);
        return sc.nextLine();
    }

    public static int leerEnteroC(String cadena) {
        Scanner sc = new Scanner(System.in);
        System.out.println(cadena);
        return sc.nextInt();
    }
}

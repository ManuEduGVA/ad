package org.dam;

import java.io.*;
import java.sql.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws SQLException, IOException {

//        ConexionDB conDB = new ConexionDB("instituto");
//        Connection con = conDB.getConexion();
//        String SQL = "Select * from persona";
//        // The statement
//        Statement st = con.createStatement();
//        // The execution
//        ResultSet rst = st.executeQuery(SQL);
//
//        // processing
//        while (rst.next()) {
//            System.out.print(Colores.Bright_Blue + "Person: " + Colores.Reset);
//            /*
//            System.out.println(
//            rst.getString(3)+ ", "+
//            rst.getString(2)+ " - "+
//            rst.getInt(5));
//            */
//            System.out.println(
//                    rst.getString("apellidos") + ", " +
//                            rst.getString("nombre") + " - " +
//                            rst.getInt("edad"));
//        }
//
//        rst.close();

        // Segundo ejemplo

//        ConexionDB conDB = new ConexionDB("instituto");
//        Connection con = conDB.getConexion();
//        // hardcoded String
//        String id_persona=Utilidades.leerTextoC("Dame el id: ");
//        // The query
//        String SQL="Select * from persona where id_persona ="+id_persona;
//        // The statement
//        Statement st=con.createStatement();
//        // The execution
//        ResultSet rst=st.executeQuery(SQL);
//
//        // processing
//        while(rst.next()){
//            System.out.print(Colores.Bright_Blue+ "Personas con " +id_persona+": "+ Colores.Reset);
//            System.out.println(
//                    rst.getString("apellidos")+ ", "+
//                            rst.getString("nombre")+ " "+
//                            rst.getInt("edad"));
//        }
//
//        rst.close();

        // Ejemplo placeHolder

//        ConexionDB conDB = new ConexionDB("instituto");
//        Connection con = conDB.getConexion();
//        // hardcoded String
//        String id_persona=Utilidades.leerTextoC("Dame el id: ");
//        // The query
//        String SQL="Select * from persona where id_persona = ?";
//
//        // The statement
//        PreparedStatement pst = con.prepareStatement(SQL);
//
//        pst.setString(1, id_persona);
//
//        // The execution
//        ResultSet rst=pst.executeQuery();
//
//        // processing
//        while(rst.next()){
//            System.out.print(Colores.Bright_Blue+ "Personas con " +id_persona+": "+ Colores.Reset);
//            System.out.println(
//                    rst.getString("apellidos")+ ", "+
//                            rst.getString("nombre")+ " "+
//                            rst.getInt("edad"));
//        }
//
//        rst.close();

        // Ejemplo de actualización

//        ConexionDB conDB = new ConexionDB("instituto");
//        Connection con = conDB.getConexion();
//        // hardcoded String
//        // give the age's bounds
//        int difEdad = Utilidades.leerEnteroC("Dame el número de años: ");
//        int idMin = Utilidades.leerEnteroC("Dame el id mínimo: ");
//        // The query
//        String SQL="Update persona set edad=edad+ ? where id_persona> ?";
//
//        // The statement
//        PreparedStatement pst = con.prepareStatement(SQL);
//
//        pst.setInt(1, difEdad);
//        pst.setInt(2, idMin);
//
//        System.out.println(pst);
//        // The execution
//        int updatedRows = pst.executeUpdate();
//
//        System.out.println(updatedRows + " han sido actualizadas");
//
//        pst.close();

        // Ejemplo de borrado

//        ConexionDB conDB = new ConexionDB("instituto");
//        Connection con = conDB.getConexion();
//        // hardcoded String
//        // give the age's bounds
//        int minEdad = Utilidades.leerEnteroC("Dame la edad mínima: ");
//        int maxEdad = Utilidades.leerEnteroC("Dame la edad máxima: ");
//        // The query
//        String SQL="Delete from persona where edad between ? and ?";
//
//        // The statement
//        PreparedStatement pst = con.prepareStatement(SQL);
//
//        pst.setInt(1, minEdad);
//        pst.setInt(2, maxEdad);
//
//        System.out.println(pst);
//        // The execution
//        int deletedRows = pst.executeUpdate();
//
//        System.out.println(deletedRows + " han sido eliminadas");
//
//        pst.close();

        // Inserciones multiples leyendo de fichero

        ConexionDB conDB = new ConexionDB("instituto");

        Connection con = conDB.getConexion();

        File script = new File("EsquemaCine.sql");

        try (BufferedReader bfr = new BufferedReader(new FileReader(script))) {

            StringBuilder sb = new StringBuilder();
            String linea;

            while ((linea = bfr.readLine()) != null) {
                // Elimina los comentarios y espacios en blanco
                linea = linea.trim();
                if (linea.isEmpty() || linea.startsWith("--") || linea.startsWith("#")) {
                    continue; // Omite líneas vacías y comentarios
                }

                sb.append(linea);

                // Si la línea termina en ';', es el final de una sentencia y deberemos ejecutar esta.
                if (linea.endsWith(";")) {
                    String query = sb.toString();
                    try (Statement stm = con.createStatement()) {
                        stm.execute(query);
                    }
                 catch (SQLException e) {
                     System.out.println("Error SQL ejecutando el script: " + e.getMessage());
                 }
                    // Reinicia el StringBuilder para la próxima sentencia
                    sb.setLength(0);

                } else {
                    // Si no, añade un espacio para separar partes de la misma sentencia
                    sb.append(" ");
                }

            }
            System.out.println("Script ejecutado correctamente.");

        } catch (IOException e) {
            System.out.println("Error de I/O al leer el script: " + e.getMessage());
        }



    }
}
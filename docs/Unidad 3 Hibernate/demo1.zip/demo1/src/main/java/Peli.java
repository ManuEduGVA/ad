import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;

@Data
@Entity
@Table(name = "Peli")
public class Peli implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPeli;

    @Column(name = "titulo", nullable = false)
    private String titulo;

    @Column(name = "anyo")
    private int anyo;

    @Column(name = "director")
    private String elDirector;

    // Constructor por defecto (OBLIGATORIO en JPA)
    public Peli() {
    }

    // Constructor con parámetros
    public Peli(String titulo, int anyo, String elDirector) {
        this.titulo = titulo;
        this.anyo = anyo;
        this.elDirector = elDirector;
    }


}

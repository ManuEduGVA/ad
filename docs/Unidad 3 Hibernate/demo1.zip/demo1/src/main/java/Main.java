import jakarta.persistence.*;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PelisUP");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx = em.getTransaction();
            tx.begin();

            // Crear y guardar nueva entidad
            Peli peli = new Peli("The Matrix", 1999, "Lana Wachowski");
            em.persist(peli);

            // Buscar entidad
            Peli encontrada = em.find(Peli.class, peli.getIdPeli());
            System.out.println("Encontrada: " + encontrada);

            // Consulta JPQL
            TypedQuery<Peli> query = em.createQuery(
                    "SELECT p FROM Peli p WHERE p.anyo >= :anio", Peli.class);
            query.setParameter("anio", 2000);
            List<Peli> pelisRecientes = query.getResultList();
            pelisRecientes.forEach(System.out::println);
            tx.commit();

        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

package org.cipfpcheste.dam2.chefai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChefAiApplicationTests {

    @Test
    void contextLoads() {
    }

}

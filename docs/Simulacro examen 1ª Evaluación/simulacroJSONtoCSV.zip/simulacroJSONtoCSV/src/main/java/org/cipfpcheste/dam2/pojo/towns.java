package org.cipfpcheste.dam2.pojo;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class towns {
    private long parent_code;
    private long town_code;
    private String label;


}

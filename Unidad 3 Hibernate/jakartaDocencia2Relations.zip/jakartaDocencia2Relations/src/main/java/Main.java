import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import modelo.Profesor;
import modelo.Modulo;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("DocenciaConsultasPU");
        EntityManager em = emf.createEntityManager();

        try {
            System.out.println("=== INICIO DEMOSTRACIÓN PERSIST vs MERGE ===\n");

            // Primero: mostrar estado actual
            mostrarEstadoActual(em);

            // Ejemplo 1: Crear nuevas entidades con PERSIST
            Persist(em);

            // Ejemplo 2: Modificar entidades existentes (evitando duplicados)
            ModificacionManaged(em);

            // Ejemplo 3: Usar MERGE con entidades detached
            MergeDetached(em);

            // Ejemplo 4: Consultas finales
            mostrarEstadoFinal(em);

            System.out.println("\n=== FIN DEMOSTRACIÓN ===");

        } catch (Exception e) {
            System.err.println("Error durante la demostración: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

    /**
     * Mostrar estado actual de las relaciones
     */
    private static void mostrarEstadoActual(EntityManager em) {
        System.out.println(" ESTADO ACTUAL DE LA BASE DE DATOS");

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            // Consultar todos los profesores y sus módulos
            List<Profesor> profesores = em.createQuery("SELECT p FROM Profesor p", Profesor.class).getResultList();

            for (Profesor profesor : profesores) {
                System.out.println(profesor.getNombre() + " (ID: " + profesor.getIdProfesor() + ")");
                System.out.println("Módulos asignados:");
                if (profesor.getModulos().isEmpty()) {
                    System.out.println("- Ninguno");
                } else {
                    profesor.getModulos().forEach(modulo ->
                            System.out.println("      - " + modulo.getNombre() + " (ID: " + modulo.getIdModulo() + ")")
                    );
                }
                System.out.println();
            }

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * EJEMPLO 1: PERSIST - Para entidades NUEVAS que no existen en la BD
     */
    private static void Persist(EntityManager em) {
        System.out.println("1. USO DE PERSIST() - CREAR NUEVAS ENTIDADES");
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            // Crear un nuevo profesor (entidad NUEVA)
            Profesor nuevoProfesor = new Profesor();
            nuevoProfesor.setNombre("Carlos Martínez");

            // Crear un nuevo módulo (entidad NUEVA)
            Modulo nuevoModulo = new Modulo();
            nuevoModulo.setNombre("Blockchain");

            // USO CORRECTO DE PERSIST: para entidades NUEVAS
            em.persist(nuevoProfesor);
            em.persist(nuevoModulo);

            // Crear relación entre ellos
            nuevoProfesor.anyadirModulo(nuevoModulo);

            tx.commit();

            System.out.println("   PERSIST exitoso:");
            System.out.println("      - Nuevo Profesor: " + nuevoProfesor.getNombre() + " (ID: " + nuevoProfesor.getIdProfesor() + ")");
            System.out.println("      - Nuevo Módulo: " + nuevoModulo.getNombre() + " (ID: " + nuevoModulo.getIdModulo() + ")");
            System.out.println("      - Relación establecida correctamente\n");

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * EJEMPLO 2: Modificación de entidades MANAGED (EVITANDO DUPLICADOS)
     */
    private static void ModificacionManaged(EntityManager em) {
        System.out.println("2. MODIFICACIÓN DE ENTIDADES MANAGED (SIN DUPLICADOS)");
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            // Obtener entidades EXISTENTES
            Profesor profesor = em.find(Profesor.class, 1L); // Mariano Faus
            // Buscar un módulo que NO esté asignado a este profesor
            Modulo moduloNoAsignado = encontrarModuloNoAsignado(em, profesor);

            if (profesor != null && moduloNoAsignado != null) {
                // Modificar propiedades
                String nombreOriginal = profesor.getNombre();
                if (!nombreOriginal.contains("[Actualizado]")) {
                    profesor.setNombre(nombreOriginal + " [Actualizado]");
                }

                // Establecer relación SOLO si no existe
                if (!existeRelacion(profesor, moduloNoAsignado)) {
                    profesor.anyadirModulo(moduloNoAsignado);

                    tx.commit();

                    System.out.println("   Modificación exitosa:");
                    System.out.println("      - Profesor: " + profesor.getNombre());
                    System.out.println("      - Nuevo módulo agregado: " + moduloNoAsignado.getNombre());
                    System.out.println("      - No se necesitó merge()\n");
                } else {
                    tx.rollback();
                    System.out.println("     Relación ya existe, no se realizaron cambios\n");
                }
            } else {
                tx.rollback();
                System.out.println("     No se encontraron entidades para modificar\n");
            }

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * EJEMPLO 3: MERGE - Para entidades DETACHED (evitando duplicados)
     */
    private static void MergeDetached(EntityManager em) {
        System.out.println("3.  USO DE MERGE() - ENTIDADES DETACHED");

        Profesor profesorDetached = null;

        // Paso 1: Obtener entidad y cerrar transacción (se vuelve DETACHED)
        EntityTransaction tx1 = em.getTransaction();
        try {
            tx1.begin();
            profesorDetached = em.find(Profesor.class, 2L); // Anna Marto
            tx1.commit();
        } catch (Exception e) {
            if (tx1.isActive()) tx1.rollback();
            throw e;
        }

        // Ahora profesorDetached está DETACHED

        EntityTransaction tx2 = em.getTransaction();
        try {
            tx2.begin();

            // Buscar un módulo que NO esté asignado a este profesor
            Modulo moduloNoAsignado = encontrarModuloNoAsignado(em, profesorDetached);

            if (moduloNoAsignado != null) {
                // Modificar la entidad DETACHED
                String nombreOriginal = profesorDetached.getNombre();
                if (!nombreOriginal.contains("[Modificado]")) {
                    profesorDetached.setNombre(nombreOriginal + " [Modificado]");
                }

                // Agregar relación SOLO si no existe
                if (!existeRelacion(profesorDetached, moduloNoAsignado)) {
                    profesorDetached.anyadirModulo(moduloNoAsignado);
                }

                // ✅ USO CORRECTO DE MERGE: para entidades DETACHED
                Profesor profesorReattached = em.merge(profesorDetached);

                tx2.commit();

                System.out.println("   MERGE exitoso:");
                System.out.println("      - Entidad DETACHED modificada y reattached");
                System.out.println("      - Nuevo nombre: " + profesorReattached.getNombre());
                if (moduloNoAsignado != null) {
                    System.out.println("      - Nuevo módulo: " + moduloNoAsignado.getNombre() + "\n");
                }
            } else {
                tx2.rollback();
                System.out.println("   No hay módulos disponibles para asignar\n");
            }

        } catch (Exception e) {
            if (tx2.isActive()) tx2.rollback();
            throw e;
        }
    }

    /**
     * Mostrar estado final
     */
    private static void mostrarEstadoFinal(EntityManager em) {
        System.out.println("4. ESTADO FINAL DE LA BASE DE DATOS");

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            // Consultar todos los profesores y sus módulos
            List<Profesor> profesores = em.createQuery("SELECT p FROM Profesor p", Profesor.class).getResultList();

            for (Profesor profesor : profesores) {
                System.out.println( profesor.getNombre() + " (ID: " + profesor.getIdProfesor() + ")");
                System.out.println("   Módulos asignados (" + profesor.getModulos().size() + "):");
                profesor.getModulos().forEach(modulo ->
                        System.out.println("      - " + modulo.getNombre() + " (ID: " + modulo.getIdModulo() + ")")
                );
                System.out.println();
            }

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * Método auxiliar: Encontrar un módulo NO asignado a un profesor
     */
    private static Modulo encontrarModuloNoAsignado(EntityManager em, Profesor profesor) {
        try {
            // Obtener todos los módulos
            List<Modulo> todosModulos = em.createQuery("SELECT m FROM Modulo m", Modulo.class).getResultList();

            // Buscar un módulo que NO esté en la lista del profesor
            for (Modulo modulo : todosModulos) {
                if (!existeRelacion(profesor, modulo)) {
                    return modulo;
                }
            }

            // Si todos están asignados, devolver null
            return null;

        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Método auxiliar: Verificar si existe relación entre profesor y módulo
     */
    private static boolean existeRelacion(Profesor profesor, Modulo modulo) {
        return profesor.getModulos().stream()
                .anyMatch(m -> m.getIdModulo().equals(modulo.getIdModulo()));
    }
}

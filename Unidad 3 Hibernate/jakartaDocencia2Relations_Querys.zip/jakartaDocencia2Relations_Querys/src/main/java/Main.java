import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.Query;
import modelo.Alumno;
import modelo.Profesor;
import modelo.Modulo;
import modelo.Examen;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("DocenciaConsultasPU");
        EntityManager em = emf.createEntityManager();

        try {
            System.out.println("=== INICIO DEMOSTRACIÓN JPQL ===\n");

            // Ejemplo 1: Consultas básicas con objetos simples
            consultasObjetosSimples(em);

            // Ejemplo 2: Consultas con objetos compuestos
            consultasObjetosCompuestos(em);

            // Ejemplo 3: Consultas con parámetros
            consultasConParametros(em);

            // Ejemplo 4: Consultas nombradas
            consultasNombradas(em);

            // Ejemplo 5: Operaciones CRUD
            operacionesCRUD(em);

            // Ejemplo 6: Consultas avanzadas con joins y agregaciones
            consultasAvanzadas(em);

            System.out.println("\n=== FIN DEMOSTRACIÓN JPQL ===");

        } catch (Exception e) {
            System.err.println("Error durante la demostración: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

    /**
     * 5.2.1. Obteniendo objetos simples
     */
    private static void consultasObjetosSimples(EntityManager em) {
        System.out.println("1. CONSULTAS CON OBJETOS SIMPLES");

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            // Consultar todos los alumnos - forma completa y tipada
            System.out.println("\n--- Todos los alumnos (forma completa) ---");
            TypedQuery<Alumno> q1 = em.createQuery("SELECT a FROM Alumno a", Alumno.class);
            List<Alumno> todosAlumnos = q1.getResultList();
            for (Alumno alumno : todosAlumnos) {
                System.out.println(alumno);
            }

            // Consultar todos los alumnos - forma simplificada
            System.out.println("\n--- Todos los alumnos (forma simplificada) ---");
            TypedQuery<Alumno> q2 = em.createQuery("FROM Alumno", Alumno.class);
            List<Alumno> alumnosSimplificado = q2.getResultList();
            for (Alumno alumno : alumnosSimplificado) {
                System.out.println(alumno.getNombre() + " " + alumno.getApellidos() + " - Edad: " + alumno.getEdad());
            }

            // Consultar un alumno específico por ID
            System.out.println("\n--- Alumno con ID 1 ---");
            TypedQuery<Alumno> q3 = em.createQuery("SELECT a FROM Alumno a WHERE a.idAlumno = :id", Alumno.class);
            q3.setParameter("id", 1L);
            try {
                Alumno alumnoEspecifico = q3.getSingleResult();
                System.out.println("Encontrado: " + alumnoEspecifico);
            } catch (Exception e) {
                System.out.println("No se encontró alumno con ID 1");
            }

            // Paginación de resultados
            System.out.println("\n--- Paginación: primeros 3 alumnos ---");
            TypedQuery<Alumno> q4 = em.createQuery("SELECT a FROM Alumno a ORDER BY a.nombre", Alumno.class);
            q4.setFirstResult(0);
            q4.setMaxResults(3);
            List<Alumno> alumnosPaginados = q4.getResultList();
            for (Alumno alumno : alumnosPaginados) {
                System.out.println(alumno.getNombre() + " " + alumno.getApellidos());
            }

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * 5.2.2. Obteniendo objetos compuestos
     */
    private static void consultasObjetosCompuestos(EntityManager em) {
        System.out.println("\n2. CONSULTAS CON OBJETOS COMPUESTOS");

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            // Consultar nombre y edad de los alumnos
            System.out.println("\n--- Nombre y edad de alumnos ---");
            TypedQuery<Object[]> q1 = em.createQuery(
                    "SELECT a.nombre, a.edad FROM Alumno a", Object[].class);
            List<Object[]> resultados = q1.getResultList();

            for (Object[] resultado : resultados) {
                String nombre = (String) resultado[0];
                Integer edad = (Integer) resultado[1];
                System.out.println("Alumno: " + nombre + ", Edad: " + edad);
            }

            // Trabajando con colecciones - número de exámenes por alumno
            System.out.println("\n--- Número de exámenes por alumno ---");
            TypedQuery<Object[]> q2 = em.createQuery(
                    "SELECT a.nombre, SIZE(a.examenes) FROM Alumno a", Object[].class);
            List<Object[]> examenesPorAlumno = q2.getResultList();

            for (Object[] resultado : examenesPorAlumno) {
                System.out.println("Alumno: " + resultado[0] + " ha realizado " + resultado[1] + " exámenes.");
            }

            // Consultar alumnos repetidores con sus datos
            System.out.println("\n--- Alumnos repetidores ---");
            TypedQuery<Object[]> q3 = em.createQuery(
                    "SELECT a.nombre, a.apellidos, a.edad FROM Alumno a WHERE a.repetidor = true", Object[].class);
            List<Object[]> repetidores = q3.getResultList();

            for (Object[] resultado : repetidores) {
                System.out.println("Repetidor: " + resultado[0] + " " + resultado[1] + " - Edad: " + resultado[2]);
            }

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * 5.3. Parámetros en JPQL
     */
    private static void consultasConParametros(EntityManager em) {
        System.out.println("\n3. CONSULTAS CON PARÁMETROS");

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            // Parámetros nominales - alumnos por rango de edad
            System.out.println("\n--- Alumnos entre 20 y 24 años ---");
            TypedQuery<Alumno> q1 = em.createQuery(
                    "SELECT a FROM Alumno a WHERE a.edad BETWEEN :minEdad AND :maxEdad", Alumno.class);
            q1.setParameter("minEdad", 20);
            q1.setParameter("maxEdad", 24);
            List<Alumno> alumnosPorEdad = q1.getResultList();
            for (Alumno alumno : alumnosPorEdad) {
                System.out.println(alumno.getNombre() + " " + alumno.getApellidos() + " - Edad: " + alumno.getEdad());
            }

            // Parámetros nominales - alumnos por nombre
            System.out.println("\n--- Alumnos llamados Pedro ---");
            TypedQuery<Alumno> q2 = em.createQuery(
                    "SELECT a FROM Alumno a WHERE a.nombre = :nombre", Alumno.class);
            q2.setParameter("nombre", "Pedro");
            List<Alumno> alumnosPedro = q2.getResultList();
            for (Alumno alumno : alumnosPedro) {
                System.out.println(alumno.getNombre() + " " + alumno.getApellidos());
            }

            // Múltiples condiciones con parámetros
            System.out.println("\n--- Alumnos no repetidores mayores de 21 años ---");
            TypedQuery<Alumno> q3 = em.createQuery(
                    "SELECT a FROM Alumno a WHERE a.repetidor = false AND a.edad > :edad", Alumno.class);
            q3.setParameter("edad", 21);
            List<Alumno> alumnosFiltrados = q3.getResultList();
            for (Alumno alumno : alumnosFiltrados) {
                System.out.println(alumno.getNombre() + " " + alumno.getApellidos() + " - Edad: " + alumno.getEdad());
            }

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * 5.3.3. Consultas nombradas
     */
    private static void consultasNombradas(EntityManager em) {
        System.out.println("\n4. CONSULTAS NOMBRADAS");

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            // Usar consultas nombradas definidas en las entidades
            System.out.println("\n--- Todos los alumnos (Named Query) ---");
            TypedQuery<Alumno> q1 = em.createNamedQuery("Alumno.findAll", Alumno.class);
            List<Alumno> todosAlumnos = q1.getResultList();
            for (Alumno alumno : todosAlumnos) {
                System.out.println(alumno.getNombre() + " " + alumno.getApellidos());
            }

            System.out.println("\n--- Alumnos repetidores (Named Query) ---");
            TypedQuery<Alumno> q2 = em.createNamedQuery("Alumno.findRepetidores", Alumno.class);
            List<Alumno> repetidores = q2.getResultList();
            for (Alumno alumno : repetidores) {
                System.out.println("Repetidor: " + alumno.getNombre() + " " + alumno.getApellidos());
            }

            System.out.println("\n--- Alumnos por edad (Named Query con parámetros) ---");
            TypedQuery<Alumno> q3 = em.createNamedQuery("Alumno.findByEdad", Alumno.class);
            q3.setParameter("edad", 24);
            List<Alumno> alumnos24 = q3.getResultList();
            for (Alumno alumno : alumnos24) {
                System.out.println("24 años: " + alumno.getNombre() + " " + alumno.getApellidos());
            }

            // Consultas nombradas de otras entidades
            System.out.println("\n--- Todos los profesores (Named Query) ---");
            TypedQuery<Profesor> q4 = em.createNamedQuery("Profesor.findAll", Profesor.class);
            List<Profesor> todosProfesores = q4.getResultList();
            for (Profesor profesor : todosProfesores) {
                System.out.println("Profesor: " + profesor.getNombre() + " - Módulos: " + profesor.getModulos().size());
            }

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * 5.4. Operaciones CRUD
     */
    private static void operacionesCRUD(EntityManager em) {
        System.out.println("\n5. OPERACIONES CRUD");

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            // CREATE - Insertar nuevo alumno
            System.out.println("\n--- CREATE - Insertar nuevo alumno ---");
            Alumno nuevoAlumno = new Alumno();
            nuevoAlumno.setNombre("Laura");
            nuevoAlumno.setApellidos("García López");
            nuevoAlumno.setEdad(22);
            nuevoAlumno.setRepetidor(false);
            em.persist(nuevoAlumno);
            System.out.println("Nuevo alumno creado: " + nuevoAlumno.getNombre() + " " + nuevoAlumno.getApellidos());

            // UPDATE - Actualizar alumno existente
            System.out.println("\n--- UPDATE - Actualizar alumno ---");
            Alumno alumnoActualizar = em.find(Alumno.class, 1L);
            if (alumnoActualizar != null) {
                String nombreOriginal = alumnoActualizar.getNombre();
                alumnoActualizar.setNombre(nombreOriginal + " [Modificado]");
                alumnoActualizar.setEdad(alumnoActualizar.getEdad() + 1);
                System.out.println("Alumno actualizado: " + alumnoActualizar.getNombre() + " - Nueva edad: " + alumnoActualizar.getEdad());
            }

            // UPDATE masivo - Incrementar edad de todos los alumnos en 1 año
            System.out.println("\n--- UPDATE masivo ---");
            Query qUpdate = em.createQuery("UPDATE Alumno a SET a.edad = a.edad + 1 WHERE a.repetidor = false");
            int actualizados = qUpdate.executeUpdate();
            System.out.println(actualizados + " alumnos actualizados");

            // DELETE masivo - Eliminar alumnos con menos de 18 años (si los hubiera)
            System.out.println("\n--- DELETE masivo ---");
            Query qDelete = em.createQuery("DELETE FROM Alumno a WHERE a.edad < 18");
            int eliminados = qDelete.executeUpdate();
            System.out.println(eliminados + " alumnos eliminados");

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    /**
     * Consultas avanzadas con joins y agregaciones
     */
    private static void consultasAvanzadas(EntityManager em) {
        System.out.println("\n6. CONSULTAS AVANZADAS");

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            // Joins implícitos - Alumnos y sus exámenes
            System.out.println("\n--- Joins implícitos: Alumnos y exámenes ---");
            TypedQuery<Object[]> q1 = em.createQuery(
                    "SELECT a.nombre, e.nota FROM Alumno a, Examen e WHERE a.idAlumno = e.alumno.idAlumno",
                    Object[].class);
            List<Object[]> alumnosExamenes = q1.getResultList();
            for (Object[] resultado : alumnosExamenes) {
                System.out.println("Alumno: " + resultado[0] + " - Nota: " + resultado[1]);
            }

            // Joins explícitos - Alumnos con notas mayores a 5
            System.out.println("\n--- Joins explícitos: Alumnos con notas > 5 ---");
            TypedQuery<Object[]> q2 = em.createQuery(
                    "SELECT a.nombre, e.nota FROM Alumno a JOIN a.examenes e WHERE e.nota > 5",
                    Object[].class);
            List<Object[]> buenasNotas = q2.getResultList();
            for (Object[] resultado : buenasNotas) {
                System.out.println("Alumno: " + resultado[0] + " - Nota: " + resultado[1]);
            }

            // Funciones de agregación - Promedio de notas por alumno
            System.out.println("\n--- Promedio de notas por alumno ---");
            TypedQuery<Object[]> q3 = em.createQuery(
                    "SELECT a.nombre, AVG(e.nota) FROM Alumno a JOIN a.examenes e GROUP BY a.nombre",
                    Object[].class);
            List<Object[]> promedios = q3.getResultList();
            for (Object[] resultado : promedios) {
                Double promedio = (Double) resultado[1];
                System.out.println("Alumno: " + resultado[0] + " - Promedio: " + String.format("%.2f", promedio));
            }

            // Contar exámenes por módulo
            System.out.println("\n--- Número de exámenes por módulo ---");
            TypedQuery<Object[]> q4 = em.createQuery(
                    "SELECT m.nombre, COUNT(e) FROM Modulo m LEFT JOIN m.examenes e GROUP BY m.nombre",
                    Object[].class);
            List<Object[]> examenesPorModulo = q4.getResultList();
            for (Object[] resultado : examenesPorModulo) {
                System.out.println("Módulo: " + resultado[0] + " - Exámenes: " + resultado[1]);
            }

            // Profesores y número de módulos que imparten
            System.out.println("\n--- Profesores y número de módulos ---");
            TypedQuery<Object[]> q5 = em.createQuery(
                    "SELECT p.nombre, SIZE(p.modulos) FROM Profesor p",
                    Object[].class);
            List<Object[]> modulosPorProfesor = q5.getResultList();
            for (Object[] resultado : modulosPorProfesor) {
                System.out.println("Profesor: " + resultado[0] + " - Módulos: " + resultado[1]);
            }

            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }
}

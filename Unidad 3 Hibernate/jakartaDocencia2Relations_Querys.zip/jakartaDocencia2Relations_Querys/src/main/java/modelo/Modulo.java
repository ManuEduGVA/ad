package modelo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Modulo")
@NamedQueries({
        @NamedQuery(name = "Modulo.findAll", query = "SELECT m FROM Modulo m"),
        @NamedQuery(name = "Modulo.findByNombre", query = "SELECT m FROM Modulo m WHERE m.nombre = :nombre")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Modulo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idModulo")
    private Long idModulo;

    @Column(name = "nombre")
    private String nombre;

    @ManyToMany(mappedBy = "modulos")
    private List<Profesor> profesores = new ArrayList<>();

    @OneToMany(mappedBy = "modulo", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Examen> examenes = new ArrayList<>();

    @Override
    public String toString() {
        return "Modulo{" +
                "idModulo=" + idModulo +
                ", nombre='" + nombre + '\'' +
                ", profesoresCount=" + (profesores != null ? profesores.size() : 0) +
                '}';
    }

    public void anyadirProfesor(Profesor profesor) {
        if (profesor != null) {
            this.profesores.add(profesor);
            profesor.getModulos().add(this); // Sincroniza el lado dueño
        }
    }

    public void eliminarProfesor(Profesor profesor) {
        if (profesor != null) {
            this.profesores.remove(profesor);
            profesor.getModulos().remove(this); // Sincroniza el lado dueño
        }
    }
}
package modelo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "Examen")
@NamedQueries({
        @NamedQuery(name = "Examen.findAll", query = "SELECT e FROM Examen e"),
        @NamedQuery(name = "Examen.findByNotaGreaterThan", query = "SELECT e FROM Examen e WHERE e.nota > :nota"),
        @NamedQuery(name = "Examen.findByAlumno", query = "SELECT e FROM Examen e WHERE e.alumno.idAlumno = :idAlumno")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Examen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idExamen")
    private Long idExamen;

    @Column(name = "fecha")
    private LocalDateTime fecha;

    @Column(name = "nota")
    private Double nota;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idAlumno")
    private Alumno alumno;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idModul")
    private Modulo modulo;

    @Override
    public String toString() {
        return "Examen{" +
                "idExamen=" + idExamen +
                ", fecha=" + fecha +
                ", nota=" + nota +
                ", alumno=" + (alumno != null ? alumno.getNombre() : "null") +
                ", modulo=" + (modulo != null ? modulo.getNombre() : "null") +
                '}';
    }
}

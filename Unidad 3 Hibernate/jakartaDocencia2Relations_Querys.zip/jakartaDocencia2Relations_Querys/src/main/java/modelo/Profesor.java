package modelo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Profesor")
@NamedQueries({
        @NamedQuery(name = "Profesor.findAll", query = "SELECT p FROM Profesor p"),
        @NamedQuery(name = "Profesor.findByNombre", query = "SELECT p FROM Profesor p WHERE p.nombre = :nombre")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Profesor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idProfesor")
    private Long idProfesor;

    @Column(name = "nombre")
    private String nombre;

    @ManyToMany
    @JoinTable(
            name = "Docencia",
            joinColumns = @JoinColumn(name = "idProfesor"),
            inverseJoinColumns = @JoinColumn(name = "idModulo")
    )
    private List<Modulo> modulos = new ArrayList<>();

    @Override
    public String toString() {
        return "Profesor{" +
                "idProfesor=" + idProfesor +
                ", nombre='" + nombre + '\'' +
                ", modulosCount=" + (modulos != null ? modulos.size() : 0) +
                '}';
    }

    public void anyadirModulo(Modulo modulo) {
        if (modulo != null) {
            this.modulos.add(modulo);
            modulo.getProfesores().add(this); // Sincroniza el lado inverso
        }
    }

    public void eliminarModulo(Modulo modulo) {
        if (modulo != null) {
            this.modulos.remove(modulo);
            modulo.getProfesores().remove(this); // Sincroniza el lado inverso
        }
    }

    // Método para verificar si tiene un módulo
    public boolean tieneModulo(Long idModulo) {
        return this.modulos.stream()
                .anyMatch(modulo -> modulo.getIdModulo().equals(idModulo));
    }
}
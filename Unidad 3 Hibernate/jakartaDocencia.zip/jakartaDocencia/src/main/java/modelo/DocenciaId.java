package modelo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocenciaId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "idProfesor")
    private Long idProfesor;

    @Column(name = "idModulo")
    private Long idModulo;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DocenciaId that = (DocenciaId) o;
        return Objects.equals(idProfesor, that.idProfesor) &&
                Objects.equals(idModulo, that.idModulo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProfesor, idModulo);
    }
}
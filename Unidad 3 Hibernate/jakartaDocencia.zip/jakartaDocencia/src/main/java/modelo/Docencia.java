package modelo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.*;

@Entity
@Table(name = "Docencia")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Docencia {

    @EmbeddedId
    private DocenciaId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("idProfesor")
    @JoinColumn(name = "idProfesor")
    private Profesor profesor;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("idModulo")
    @JoinColumn(name = "idModulo")
    private Modulo modulo;
}

import modelo.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import java.time.LocalDateTime;

public class Main{

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("DocenciaConsultasPU");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();

            // Crear un nuevo profesor y asignarle múltiples módulos
            Profesor nuevoProfesor = new Profesor();
            nuevoProfesor.setNombre("Jose Manuel Romero");
            em.persist(nuevoProfesor);

            // Asignar módulos al nuevo profesor
            Modulo modulo1 = em.find(Modulo.class, 3L); // EIE
            Modulo modulo2 = em.find(Modulo.class, 6L); // ACD



            // Primera asignación
            Docencia docencia1 = new Docencia();
            docencia1.setId(new DocenciaId(nuevoProfesor.getIdProfesor(), modulo1.getIdModulo()));
            docencia1.setProfesor(nuevoProfesor);
            docencia1.setModulo(modulo1);
            em.persist(docencia1);

            // Segunda asignación
            Docencia docencia2 = new Docencia();
            docencia2.setId(new DocenciaId(nuevoProfesor.getIdProfesor(), modulo2.getIdModulo()));
            docencia2.setProfesor(nuevoProfesor);
            docencia2.setModulo(modulo2);
            em.persist(docencia2);

//            // Crear un nuevo alumno y agregarle exámenes
//            Alumno nuevoAlumno = new Alumno();
//            nuevoAlumno.setNombre("Marta");
//            nuevoAlumno.setApellidos("Rodriguez Santos");
//            nuevoAlumno.setEdad(23);
//            nuevoAlumno.setRepetidor(true);
//            em.persist(nuevoAlumno);
//
//            // Agregar exámenes al alumno
//            Examen examen1 = new Examen();
//            examen1.setFecha(LocalDateTime.of(2024, 1, 15, 10, 0));
//            examen1.setNota(7.0);
//            examen1.setAlumno(nuevoAlumno);
//            examen1.setModulo(modulo1);
//            em.persist(examen1);
//
//            Examen examen2 = new Examen();
//            examen2.setFecha(LocalDateTime.of(2024, 1, 20, 9, 0));
//            examen2.setNota(5.5);
//            examen2.setAlumno(nuevoAlumno);
//            examen2.setModulo(modulo2);
//            em.persist(examen2);

            tx.commit();
            System.out.println("Inserción compleja completada:");
            System.out.println("- Profesor: " + nuevoProfesor.getNombre() + " (ID: " + nuevoProfesor.getIdProfesor() + ")");
//            System.out.println("- Alumno: " + nuevoAlumno.getNombre() + " " + nuevoAlumno.getApellidos());
//            System.out.println("- Módulos asignados: " + modulo1.getNombre() + ", " + modulo2.getNombre());
//            System.out.println("- Exámenes creados: 2");

        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}

package org.cipfpcheste.dam2.https;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpsApplicationTests {

    @Test
    void contextLoads() {
    }

}

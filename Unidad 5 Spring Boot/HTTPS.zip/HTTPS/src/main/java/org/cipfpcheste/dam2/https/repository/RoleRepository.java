package org.cipfpcheste.dam2.https.repository;

import org.cipfpcheste.dam2.https.models.ERole;
import org.cipfpcheste.dam2.https.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByName(ERole name);
}

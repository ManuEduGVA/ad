import jakarta.persistence.*;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        System.out.println("Ejemplo de BBDDOO con ObjectDB");
        EntityManagerFactory emf = null;
        EntityManager em = null;
        try {

            emf = Persistence.createEntityManagerFactory("objectdb-unit");
            em = emf.createEntityManager();

            // Crear productos
            Producto portatil = new Producto("Asus TUF", 1299.99, "Portatil para gamers");
            Producto raton = new Producto("Ratón Inalámbrico", 49.99, "Ratón de baja calidad");
            Producto teclado = new Producto("Teclado Mecánico", 89.99, "Teclado mecánico RGB");

            // Persistir (CREATE)
            EntityTransaction transaction = em.getTransaction();
            transaction.begin();

            em.persist(portatil);
            em.persist(raton);
            em.persist(teclado);

            transaction.commit();
            System.out.println("Productos persistidos: " + portatil.getId() + ", " + raton.getId() + ", " + teclado.getId());

            // Lectura del portátil
             Producto busquedaProducto = em.find(Producto.class, portatil.getId());
            System.out.println("Productos: " + busquedaProducto);

            // Actualizar
            transaction.begin();
            busquedaProducto.setPrecio(1199.99);
            em.merge(busquedaProducto);
            transaction.commit();
            System.out.println("Producto actualizado: " + busquedaProducto);

            // Verificar actualización
            Producto productoActualizado = em.find(Producto.class, portatil.getId());
            System.out.println("Precio actualizado verificado: " + productoActualizado.getPrecio());

            // Realización de consultas con JPQL

            System.out.println("*".repeat(100));
            System.out.println("\n                            --- Prueba de consultas JPQL ---");
            System.out.println("*".repeat(100));

            // Consulta todos los productos
            TypedQuery<Producto> todoslosProductosQuery =
                    em.createQuery("SELECT p FROM Producto p ORDER BY p.precio DESC", Producto.class);
            List<Producto> todoslosProductos = todoslosProductosQuery.getResultList();

            System.out.println("Todos los productos (" + todoslosProductos.size() + "):");
            for (Producto producto : todoslosProductos) {
                System.out.println("   - " + producto);
            }

            // Consulta con filtro
            TypedQuery<Producto> productosCarosQuery =
                    em.createQuery("SELECT p FROM Producto p WHERE p.precio > 100", Producto.class);
            List<Producto> productosCaros = productosCarosQuery.getResultList();

            System.out.println("Productos caros (>100€): " + productosCaros.size());

            // Consulta con parámetros
            TypedQuery<Producto> QueryParametros =
                    em.createQuery("SELECT p FROM Producto p WHERE p.nombre LIKE :nombre", Producto.class);
            QueryParametros.setParameter("nombre", "%Ratón%");
            List<Producto> ProductoRaton = QueryParametros.getResultList();

            System.out.println("Productos con 'Ratón' en el nombre: " + ProductoRaton.size());

            System.out.println("*".repeat(100));

        } catch (Exception e) {
            System.err.println("Error de ejecución:");
            e.printStackTrace();
        } finally {
            // 5. Cerrar recursos
            if (em != null && em.isOpen()) {
                em.close();
                System.out.println("EntityManager cerrado");
            }
            if (emf != null && emf.isOpen()) {
                emf.close();
                System.out.println("EntityManagerFactory cerrado");
            }
        }
    }

}